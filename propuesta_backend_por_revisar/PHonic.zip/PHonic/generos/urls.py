from django.urls import path
# from .views import <vistas de la app generos>

urlpatterns = [
    # path('ruta/', vista, name='nombre'),
]

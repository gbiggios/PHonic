from django.urls import path
# from .views import <vistas de la app discos>

urlpatterns = [
    # path('ruta/', vista, name='nombre'),
]

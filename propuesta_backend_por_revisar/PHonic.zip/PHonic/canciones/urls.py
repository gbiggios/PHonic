from django.urls import path
# from .views import <vistas de la app canciones>

urlpatterns = [
    # path('ruta/', vista, name='nombre'),
]
